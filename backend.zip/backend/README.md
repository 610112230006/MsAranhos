# สร้าง Docker Images

docker build . -t node-ms-aranhos:1.0

# รัน Images

docker run -p 2000:3000 node-ms-aranhos:1.0